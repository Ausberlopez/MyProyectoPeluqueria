namespace PeluqueriaStar.App.Dominio
{
    public class HorarioEstelista 
    {
    public int Id {get; set; }
   	
   	public string Fecha {get; set; }
   	public string Horario {get; set; }

    }
}