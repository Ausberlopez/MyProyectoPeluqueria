namespace PeluqueriaStar.App.Dominio
{
    public class ServiciosOfrecer
    {
    public int Id  {get; set; }
   	public string Categoria {get; set; }
   	public string Descripcion{get; set; }
   	public int ValorServicio {get; set; }
   	public string Comentario {get; set; }

    }
}