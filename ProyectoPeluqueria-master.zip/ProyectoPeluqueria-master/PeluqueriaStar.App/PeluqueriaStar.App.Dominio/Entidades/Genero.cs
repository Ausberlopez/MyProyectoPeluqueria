namespace PeluqueriaStar.App.Dominio
{
    public enum Genero
    {
        Masculino,
        Femeninio
    }
}