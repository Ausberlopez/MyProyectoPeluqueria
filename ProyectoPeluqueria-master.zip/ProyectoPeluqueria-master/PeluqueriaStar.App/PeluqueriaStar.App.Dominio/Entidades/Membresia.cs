namespace PeluqueriaStar.App.Dominio
{
    public class Membresia
    {
       public int Id { get; set; }   

       public bool ActivadaMembresia { get; set; }
       public int ValorDescuento { get; set; }
    }
}